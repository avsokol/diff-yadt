/* Parse arguments from a string and prepend them to an argv.  */

void prepend_default_options (char const *, int *, char ***);
